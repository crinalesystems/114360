114360 - EN - Install Guide for XBOX 360 / Xenia - rev0

Hello, this is the installation guide for FFXI for 360. Some things need to be covered first:

1. The launcher saves the passwords of your PlayOnline accounts in launcher.ini in PLAIN TEXT.
2. The launcher was built with a later XDK than the NXE and Blades dashboards; expect unexpected crashes.
3. The launcher hasn't been tested on real hardware. It should work, but emulation and hardware differ.
4. If the folder structure doesn't match what follows, expect a crash. The in-game menu MIGHT crash outright
   on a console where Xenia doesn't: exceptions thrown there mean something is off.


WHAT YOU NEED

  - Your FINAL FANTASY XI 2016 client (40160203_0): a folder holding 0001\ (FFXi.dll, FFXiMain.dll,
    CONFIG.SYS, ROM\, ROM2\ ...) or those files directly. Required.
  - Optionally the September 2010 data, same layout. Program files it lacks are taken from the 2016 client.
  - A FINAL FANTASY XI Xbox 360 disc image (.iso), or a copy of its PlayOnline folder. Only the PlayOnline
    data is taken from it; none of its programs run.

  PolCore (PlayOnline 20110726_A) and the PlayOnline files changed after the disc are downloaded from
  PlayOnline's update server, which still answers. You can give your own PolCore.xex instead. area.dat is
  4 bytes (the region code); one is written if you have none.


INSTALL

  Windows: 114360-installer.exe        Linux: ./114360-installer

  Choose the install location (a USB drive is easiest), the 2016 client, optionally the 2010 data, and the
  disc image. Press Check, read the results at the bottom, then Install. Installing again later only copies
  what changed.

  Command line, same thing without the window:
    114360-installer <INSTALL LOCATION> -4016 <2016 root> [-2010 <2010 root>] -iso <disc.iso>
                     -polcore download -update-pol [-check]


THE RESULT

  <folder>\default.xex, launcher.ini     the launcher
  <folder>\area.dat, PlayOnline\         PlayOnline's data
  <folder>\rev\40160203_0\               the 2016 client (required)
  <folder>\rev\sep2010\                  the 2016 client with 2010 data (optional)

  Each client folder is about 11 GB.


RUNNING IT

  Aurora: put <folder> on a USB drive or the HDD (Hdd1:\Games\FFXI, for example), then
  Settings -> Content -> Scan Paths, depth 1, and rescan. You can also open default.xex in the File Manager.
  It shows up as FINAL FANTASY XI.

  Xenia: open <folder>\default.xex.

  No DNS or other network tomfoolery is needed: servers are given by IPv4 address, so any server can be
  reached. launcher.ini comes with two Project Crystal presets (Crystal2010 and Crystal2016); enter your
  PlayOnline ID and password in the menu. A USB keyboard works for the menus and the chat page.


INCLUDED

  Noto Sans (payload/font.ttf), SIL Open Font License 1.1. SDL3 (zlib license), FreeType (FreeType License),
  zlib, libpng and bzip2 on Windows.
